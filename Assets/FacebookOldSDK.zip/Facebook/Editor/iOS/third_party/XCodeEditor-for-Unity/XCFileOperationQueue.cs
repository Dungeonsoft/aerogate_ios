using UnityEngine;
using System.Collections;

namespace UnityEditor.XCodeEditor
{
	public class XCFileOperationQueue : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}